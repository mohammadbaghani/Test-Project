export const API_BASE_URL="https://api.themoviedb.org/3";
export const API_KEY="f5ac2a4ab0c583a1411b3def918ac2c4";
export const IMAGE_BASE_URL="https://image.tmdb.org/t/p/w500";